package com.example.emotions;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.ToggleButton;
public class MainActivity extends AppCompatActivity {

    private TextView textresult;
    private CheckBox CheckRiu,Checkchorou,CheckCansado,CheckDivertiu,CheckRelaxou;
    private Button BtnRefazer,Btncalc;
    private ToggleButton ToggleSN;
    private ImageView ImgFelix,ImgNeutro,ImgTriste;
    private int triste=0;
    private int feliz=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        AlertDialog.Builder Alerta = new AlertDialog.Builder(this);
        Alerta.setTitle("Como está se sentindo hoje?")
                .setMessage("Escolha ao menos uma das opções, por favor!");
        Alerta.show();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        CheckRiu=findViewById(R.id.checkRiu);
        Checkchorou=findViewById(R.id.checkChorou);
        CheckCansado=findViewById(R.id.checkCansado);
        CheckDivertiu=findViewById(R.id.checkDivertiu);
        CheckRelaxou=findViewById(R.id.checkrelaxou);
        ToggleSN=findViewById(R.id.TogleSN);
        ImgFelix=findViewById(R.id.ImgFeliz);
        ImgNeutro=findViewById(R.id.ImgNeutro);
        ImgTriste=findViewById(R.id.ImgTriste);
        Btncalc=findViewById(R.id.Btncalc);
        BtnRefazer=findViewById(R.id.BtnRefazer);

        Riu();
        Chorou();
        Relaxou();
        Divertiu();
        Cansado();
        SN();
        Btncalc.setOnClickListener(view -> {
            Calcular();
        });
        BtnRefazer.setOnClickListener(view -> {
            triste=0;
            feliz=0;
            ImgTriste.setVisibility(View.INVISIBLE);
            ImgNeutro.setVisibility(View.INVISIBLE);
            ImgFelix.setVisibility(View.INVISIBLE);
            textresult.setText("Resultado:");

        });


    }

    public void Riu(){
        CheckRiu.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(CheckRiu.isChecked()){
                    feliz++;
                }else {

                }}
        });}
    public void Chorou(){
        Checkchorou.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(Checkchorou.isChecked()){
                    triste++;
                }else {

                }}
        });}
    public void Relaxou(){
        CheckRelaxou.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(CheckRelaxou.isChecked()){
                    feliz++;
                }else {

                }}
        });}
    public void Divertiu(){
        CheckDivertiu.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(CheckDivertiu.isChecked()){
                    feliz++;
                }else {

                }}
        });}
    public void Cansado(){
        CheckCansado.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(CheckCansado.isChecked()){
                    triste++;
                }else {

                }}
        });}
    public void SN (){
        ToggleSN.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener(){
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(ToggleSN.isChecked()){
                    triste++;
                }else {
                    feliz++;
                }}
        });}
    private void Calcular(){
        textresult=findViewById(R.id.TextResult);
        if (triste>feliz){
            ImgTriste.setVisibility(View.VISIBLE);
            textresult.setText("Você está triste hoje, melhoras!");
        }
        else if(feliz==triste){
            ImgNeutro.setVisibility(View.VISIBLE);
            textresult.setText("Nem feliz nem triste, não é tão ruim!");

        }
        else{
            ImgFelix.setVisibility(View.VISIBLE);
            textresult.setText("Você está feliz, que bom!");
        }
    }
}